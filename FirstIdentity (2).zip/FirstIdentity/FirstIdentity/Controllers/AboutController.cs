﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirstIdentity.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FirstIdentity.Controllers
{
    [Authorize(Roles ="Admin,Member")]
    
    public class AboutController : Controller
    {
        //[AllowAnonymous]
        public IActionResult Index()
        {
            return Content("About index");
        }

        public IActionResult Test()
        {
            return Content("About test");
        }
    }
}